<?php
if($_POST){
    echo '<pre>';print_r($_POST);die;
}
?>